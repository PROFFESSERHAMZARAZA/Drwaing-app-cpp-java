# 🎨 Drawing App

### A Java Swing Paint Application with Custom Color Options | OOP Semester Project

[![Language](https://img.shields.io/badge/Language-Java-007396?style=flat-square&logo=java)](https://www.java.com/) [![GUI](https://img.shields.io/badge/GUI-Swing-orange?style=flat-square)](#) [![Platform](https://img.shields.io/badge/Platform-Windows%20%7C%20Linux%20%7C%20macOS-lightgrey?style=flat-square)](#-getting-started) [![License](https://img.shields.io/badge/License-MIT-green?style=flat-square)](LICENSE) [![Status](https://img.shields.io/badge/Status-Completed-brightgreen?style=flat-square)](#)

*A lightweight, MS-Paint-style drawing application built from scratch in Java Swing, demonstrating core Object-Oriented Programming principles through a clean, event-driven GUI.*

[Features](#-features) • [Screenshots](#️-screenshots) • [OOP Concepts](#-oop-concepts-explained) • [Getting Started](#-getting-started) • [Project Structure](#-project-structure)

---

## 📖 Overview

**Drawing App** is a Java Swing-based paint program built for an Object-Oriented Programming semester project. It lets users freehand draw, erase, draw straight lines, pick any custom color, adjust brush size, undo/redo their strokes, and export the finished artwork as a PNG image.

The project was built to demonstrate a clean, practical application of OOP in Java — using enums, inheritance, interfaces, and encapsulated state — on top of the `Graphics2D` rendering API.

> 📄 A full written report covering the project's objectives, design, and OOP concept breakdown is available at [`docs/Project_Report.pdf`](docs/Project_Report.pdf).

---

## ✨ Features

- 🖊️ **Pen Tool** — smooth, antialiased freehand drawing
- 🧹 **Eraser Tool** — remove parts of a drawing
- 📏 **Line Tool** — draw perfectly straight lines
- 🎨 **Custom Color Picker** — pick any color via a full `JColorChooser` dialog
- 🔧 **Adjustable Brush Size** — live slider control
- ↩️ **Undo / Redo** — full stroke-history stack
- 💾 **Save as PNG** — export your canvas as an image file
- ⚠️ **Exit Confirmation** — prevents accidental loss of work

---

## 🖼️ Screenshots

**Freehand Drawing on the Canvas**

![App Preview](docs/screenshots/01_app_preview.png)

**Custom Color Picker**

![Color Picker](docs/screenshots/02_color_picker.png)

---

## 🎯 OOP Concepts Explained

| Concept | Where it's used |
|---|---|
| **Encapsulation** | Canvas state (strokes, active color, brush size) is kept private inside `PaintCanvas` and only exposed through controlled methods |
| **Abstraction** | Drawing logic is abstracted behind simple calls like `drawStroke()` and `saveImage()`, hiding the underlying `Graphics2D` details |
| **Enumeration** | A `Tool` enum models the active drawing tool (`PEN`, `ERASER`, `LINE`) |
| **Inheritance** | `PaintFrame` extends `JFrame`; `PaintCanvas` extends `JPanel` |
| **Interfaces** | `PaintCanvas` implements `MouseListener` and `MouseMotionListener` to handle drawing input |
| **Composition** | Each `Stroke` object is composed of a tool, color, size, and a list of points |
| **Event-driven design** | Lambda-based `ActionListener` / `ChangeListener` callbacks drive every toolbar control |

---

## 🚀 Getting Started

### Prerequisites
- JDK 8 or later
- Any Java IDE (Eclipse, IntelliJ IDEA, VS Code) — or just a terminal

### Run from the command line

```bash
git clone https://github.com/<your-username>/Drawing-App.git
cd Drawing-App

# Compile
javac PaintApplication.java

# Run
java PaintApplication
```

### Run from an IDE
1. Open the project folder in your IDE.
2. Run `PaintApplication.java` — it contains the `main` method.

---

## 🖱️ How to Use

1. Pick a **tool** — Pen, Eraser, or Line — from the toolbar.
2. Click **Color** to open the color picker and choose a drawing color.
3. Drag the **Size** slider to change brush thickness.
4. Click and drag on the canvas to draw.
5. Use **Undo** / **Redo** to step back and forward through your strokes.
6. Click **Save** to export your drawing as a PNG file.
7. Click **Exit** (or close the window) to quit — you'll be asked to confirm.

---

## 📁 Project Structure

```
Drawing-App/
├── PaintApplication.java     # Complete source code (frame, canvas, tools)
├── docs/
│   ├── Project_Report.pdf    # Full semester project report
│   ├── Project_Report.docx
│   └── screenshots/          # App screenshots
├── LICENSE
└── README.md
```

---

## 🛠️ Tech Stack

- **Language:** Java (JDK 8+)
- **GUI Toolkit:** Java Swing (`javax.swing`, `java.awt`)
- **Image I/O:** `javax.imageio` for PNG export

---

## 🔮 Future Enhancements

- [ ] Add a rectangle / ellipse / polygon shape tool
- [ ] Add a fill-bucket tool
- [ ] Add layers support
- [ ] Add a custom brush texture picker
- [ ] Package as a runnable `.jar`

---

## 👤 Author

**Muhammad Hamza (PROFFESSER)**
BS Cyber Security — Air University, Kamra Campus

---

## 📜 License

This project is licensed under the [MIT License](LICENSE) — free to use, modify, and distribute for learning purposes.

---

*⭐ If you found this project helpful, consider giving it a star!*
