import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.*;
import javax.imageio.ImageIO;

/* ================= MAIN ================= */

public class PaintApplication {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(PaintFrame::new);
    }
}

/* ================= FRAME ================= */

class PaintFrame extends JFrame {

    public PaintFrame() {

        setTitle("MS Paint Clone - Java");
        setSize(1300, 800);
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        setLocationRelativeTo(null);

        PaintCanvas canvas = new PaintCanvas();

        add(canvas); // ❌ NO SCROLL PANE (NO PAGE SCROLL)

        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                canvas.confirmExit();
            }
        });

        setVisible(true);
    }
}

/* ================= TOOL ENUM ================= */

enum Tool {
    PEN, ERASER, LINE
}

/* ================= CANVAS ================= */

class PaintCanvas extends JPanel implements MouseListener, MouseMotionListener {

    private java.util.List<Stroke> strokes = new ArrayList<>();
    private Stroke currentStroke;

    private Color currentColor = Color.BLACK;
    private int brushSize = 5;
    private Tool currentTool = Tool.PEN;

    private java.util.List<Stroke> redoStack = new ArrayList<>();

    /* ================= STROKE ================= */

    class Stroke {
        Tool tool;
        Color color;
        int size;
        java.util.List<Point> points = new ArrayList<>();

        Stroke(Tool t, Color c, int s) {
            tool = t;
            color = c;
            size = s;
        }
    }

    /* ================= CONSTRUCTOR ================= */

    public PaintCanvas() {

        setBackground(Color.WHITE);

        /* FIXED SIZE = NO SCROLLING */
        setPreferredSize(new Dimension(1300, 800));

        setLayout(new BorderLayout());

        createToolbar();

        addMouseListener(this);
        addMouseMotionListener(this);
    }

    /* ================= TOOLBAR ================= */

    private void createToolbar() {

        JPanel bar = new JPanel();

        JButton pen = new JButton("Pen");
        JButton eraser = new JButton("Eraser");
        JButton line = new JButton("Line");

        pen.addActionListener(e -> currentTool = Tool.PEN);
        eraser.addActionListener(e -> currentTool = Tool.ERASER);
        line.addActionListener(e -> currentTool = Tool.LINE);

        JButton colorBtn = new JButton("Color");
        colorBtn.addActionListener(e -> {
            Color c = JColorChooser.showDialog(
                    this,
                    "Pick Color",
                    currentColor
            );
            if (c != null) currentColor = c;
        });

        JButton undo = new JButton("Undo");
        JButton redo = new JButton("Redo");

        undo.addActionListener(e -> {
            if (!strokes.isEmpty()) {
                redoStack.add(strokes.remove(strokes.size() - 1));
                repaint();
            }
        });

        redo.addActionListener(e -> {
            if (!redoStack.isEmpty()) {
                strokes.add(redoStack.remove(redoStack.size() - 1));
                repaint();
            }
        });

        JButton save = new JButton("Save");
        save.addActionListener(e -> saveImage());

        JButton exit = new JButton("Exit");
        exit.addActionListener(e -> confirmExit());

        JSlider size = new JSlider(1, 50, 5);
        size.addChangeListener(e -> brushSize = size.getValue());

        bar.add(pen);
        bar.add(eraser);
        bar.add(line);
        bar.add(colorBtn);
        bar.add(new JLabel("Size"));
        bar.add(size);
        bar.add(undo);
        bar.add(redo);
        bar.add(save);
        bar.add(exit);

        add(bar, BorderLayout.NORTH);
    }

    /* ================= DRAW ================= */

    @Override
    protected void paintComponent(Graphics g) {

        super.paintComponent(g);

        Graphics2D g2 = (Graphics2D) g;

        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                RenderingHints.VALUE_ANTIALIAS_ON);

        for (Stroke s : strokes) {
            drawStroke(g2, s);
        }

        if (currentStroke != null) {
            drawStroke(g2, currentStroke);
        }
    }

    private void drawStroke(Graphics2D g2, Stroke s) {

        g2.setStroke(new BasicStroke(s.size));

        if (s.tool == Tool.ERASER) {
            g2.setColor(Color.WHITE);
        } else {
            g2.setColor(s.color);
        }

        for (int i = 1; i < s.points.size(); i++) {
            Point p1 = s.points.get(i - 1);
            Point p2 = s.points.get(i);
            g2.drawLine(p1.x, p1.y, p2.x, p2.y);
        }
    }

    /* ================= MOUSE ================= */

    public void mousePressed(MouseEvent e) {

        currentStroke = new Stroke(currentTool, currentColor, brushSize);
        currentStroke.points.add(e.getPoint());

        strokes.add(currentStroke);
        redoStack.clear();
    }

    public void mouseDragged(MouseEvent e) {
        currentStroke.points.add(e.getPoint());
        repaint();
    }

    public void mouseReleased(MouseEvent e) {
        currentStroke = null;
    }

    public void mouseClicked(MouseEvent e) {}
    public void mouseEntered(MouseEvent e) {}
    public void mouseExited(MouseEvent e) {}
    public void mouseMoved(MouseEvent e) {}

    /* ================= SAVE ================= */

    private void saveImage() {

        try {
            BufferedImage img = new BufferedImage(
                    getWidth(),
                    getHeight(),
                    BufferedImage.TYPE_INT_ARGB
            );

            Graphics2D g2 = img.createGraphics();
            paint(g2);
            g2.dispose();

            JFileChooser chooser = new JFileChooser();

            if (chooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
                ImageIO.write(img, "png", chooser.getSelectedFile());
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    /* ================= EXIT CONFIRM (CENTER MESSAGE) ================= */

    public void confirmExit() {

        JOptionPane optionPane = new JOptionPane(
                "Are you sure you want to exit?",
                JOptionPane.QUESTION_MESSAGE,
                JOptionPane.YES_NO_OPTION
        );

        JDialog dialog = optionPane.createDialog(this, "Exit Confirmation");

        /* FORCE CENTER POSITION */
        dialog.setLocationRelativeTo(this);

        dialog.setVisible(true);

        Object result = optionPane.getValue();

        if (result != null && result.equals(JOptionPane.YES_OPTION)) {
            System.exit(0);
        }
    }
}